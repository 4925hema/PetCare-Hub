import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { z } from 'zod';

const createRentalSchema = z.object({
  userId: z.string(),
  petId: z.string(),
  providerId: z.string(),
  startDate: z.string(),
  endDate: z.string(),
  totalPrice: z.number().positive(),
});

const updateRentalSchema = z.object({
  status: z.enum(['Pending', 'Active', 'Completed', 'Cancelled']).optional(),
});

// Create a new rental
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, petId, providerId, startDate, endDate, totalPrice } = createRentalSchema.parse(body);

    // Verify user exists
    const user = await db.user.findUnique({
      where: { id: userId }
    });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Verify pet exists and is available
    const pet = await db.pet.findUnique({
      where: { id: petId }
    });

    if (!pet) {
      return NextResponse.json(
        { error: 'Pet not found' },
        { status: 404 }
      );
    }

    if (pet.status !== 'Available') {
      return NextResponse.json(
        { error: 'Pet is not available for rental' },
        { status: 400 }
      );
    }

    // Verify provider exists
    const provider = await db.provider.findUnique({
      where: { id: providerId }
    });

    if (!provider) {
      return NextResponse.json(
        { error: 'Provider not found' },
        { status: 404 }
      );
    }

    // Create rental
    const rental = await db.rental.create({
      data: {
        userId,
        petId,
        providerId,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        totalPrice,
        status: 'Pending',
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          }
        },
        pet: {
          select: {
            id: true,
            name: true,
            type: true,
            status: true,
          }
        },
        provider: {
          select: {
            id: true,
            name: true,
            email: true,
          }
        }
      }
    });

    return NextResponse.json({
      message: 'Rental created successfully',
      rental,
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      );
    }

    console.error('Rental creation error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// Update rental status and pet availability
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { rentalId, status } = body;

    if (!rentalId || !status) {
      return NextResponse.json(
        { error: 'Rental ID and status are required' },
        { status: 400 }
      );
    }

    const validatedStatus = updateRentalSchema.parse({ status }).status;

    // Find rental with related data
    const rental = await db.rental.findUnique({
      where: { id: rentalId },
      include: {
        pet: true
      }
    });

    if (!rental) {
      return NextResponse.json(
        { error: 'Rental not found' },
        { status: 404 }
      );
    }

    // Update rental status
    const updatedRental = await db.rental.update({
      where: { id: rentalId },
      data: { status: validatedStatus },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          }
        },
        pet: {
          select: {
            id: true,
            name: true,
            type: true,
            status: true,
          }
        },
        provider: {
          select: {
            id: true,
            name: true,
            email: true,
          }
        }
      }
    });

    // Update pet status based on rental status
    let petStatus = 'Available';
    if (validatedStatus === 'Active') {
      petStatus = 'Rented';
    } else if (validatedStatus === 'Completed' || validatedStatus === 'Cancelled') {
      petStatus = 'Available';
    }

    await db.pet.update({
      where: { id: rental.petId },
      data: { status: petStatus }
    });

    return NextResponse.json({
      message: 'Rental status updated successfully',
      rental: updatedRental,
      petStatus: petStatus,
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      );
    }

    console.error('Rental update error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}