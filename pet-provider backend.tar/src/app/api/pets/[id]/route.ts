import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { z } from 'zod';

const updatePetSchema = z.object({
  name: z.string().min(1).optional(),
  type: z.string().min(1).optional(),
  breed: z.string().optional(),
  age: z.number().min(0).optional(),
  description: z.string().optional(),
  price: z.number().positive().optional(),
  image: z.string().optional(),
  status: z.enum(['Available', 'Rented']).optional(),
});

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const petId = params.id;
    const body = await request.json();
    const updateData = updatePetSchema.parse(body);

    // Check if pet exists
    const existingPet = await db.pet.findUnique({
      where: { id: petId },
      include: {
        provider: {
          select: {
            id: true,
            name: true,
            email: true,
          }
        }
      }
    });

    if (!existingPet) {
      return NextResponse.json(
        { error: 'Pet not found' },
        { status: 404 }
      );
    }

    // Update pet
    const updatedPet = await db.pet.update({
      where: { id: petId },
      data: updateData,
      include: {
        provider: {
          select: {
            id: true,
            name: true,
            email: true,
          }
        }
      }
    });

    return NextResponse.json({
      message: 'Pet updated successfully',
      pet: updatedPet,
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      );
    }

    console.error('Pet update error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const petId = params.id;

    // Check if pet exists
    const existingPet = await db.pet.findUnique({
      where: { id: petId }
    });

    if (!existingPet) {
      return NextResponse.json(
        { error: 'Pet not found' },
        { status: 404 }
      );
    }

    // Delete pet (this will also delete related rentals due to cascade)
    await db.pet.delete({
      where: { id: petId }
    });

    return NextResponse.json({
      message: 'Pet deleted successfully',
    });
  } catch (error) {
    console.error('Pet deletion error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}