import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { z } from 'zod';

const createPetSchema = z.object({
  name: z.string().min(1),
  type: z.string().min(1),
  breed: z.string().optional(),
  age: z.number().min(0).optional(),
  description: z.string().optional(),
  price: z.number().positive(),
  image: z.string().optional(),
  providerId: z.string(),
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const petData = createPetSchema.parse(body);

    // Verify provider exists
    const provider = await db.provider.findUnique({
      where: { id: petData.providerId }
    });

    if (!provider) {
      return NextResponse.json(
        { error: 'Provider not found' },
        { status: 404 }
      );
    }

    // Create pet
    const pet = await db.pet.create({
      data: {
        name: petData.name,
        type: petData.type,
        breed: petData.breed,
        age: petData.age,
        description: petData.description,
        price: petData.price,
        image: petData.image,
        providerId: petData.providerId,
        status: 'Available',
      },
      include: {
        provider: {
          select: {
            id: true,
            name: true,
            email: true,
          }
        }
      }
    });

    return NextResponse.json({
      message: 'Pet created successfully',
      pet,
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      );
    }

    console.error('Pet creation error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}